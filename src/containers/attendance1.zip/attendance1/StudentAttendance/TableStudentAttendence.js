import React, {useEffect,useState } from 'react';
import 'react-calendar/dist/Calendar.css';
import Layout from 'containers/Layout';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Grid from '@material-ui/core/Grid';
import axiosInstance from '../../../config/axios';
import endpoints from '../../../config/endpoints';
import AttendenceTable from './AttendenceTable';
import './tablestudentattendance.scss';




const Admin = () => {
const [dateState, setDateState] = useState(new Date());
const [spacing, setSpacing] = React.useState(2);
const [getDatastudent,setGetDatastudent] = React.useState();
const [getData,setGetData] = React.useState([]);
const [flag,setFlag]=React.useState(false)
const changeDate = (e) => {
setDateState(e);
};
const useStyles = makeStyles((theme) => ({
margin: theme.spacing(2),
}));
const classes = useStyles();
React.useEffect(()=>{ 
axiosInstance(endpoints.Calendar_attendance.Monthly_attendance).then((res)=>{
console.log("response",res.data.result.students_list)
setGetData(res.data.result.students_list)
})

},[])
useEffect(()=>{
axiosInstance(endpoints.Calendar_attendance.Student_calender).then((res)=>{
console.log("response1",res.data.result.events)
setGetDatastudent(res.data.result.events)
})

},[])
const handleClick=(e)=>{
e.preventDefault()
console.log("open sheet")
setFlag(true)

}
return (
<>
  <Layout> 
    {/* <Grid container direction="row" spacing={2} style={{ marginTop: '2%',marginLeft: '20px'}} > */}
    <Grid container direction="row" spacing={2} className="Gview1" >
      <Grid item md={2} xs={12}>
        <Autocomplete
          style={{width:250}}
          id="combo-box-demo"
          options={getDatastudent}
          getOptionLabel={(option) => option.grade_id }
          renderInput={(params) => <TextField {...params} label="Academic" variant="outlined" />}
        />
      </Grid>
      <Grid item md={2} xs={12} > 
        <Autocomplete
          style={{width:250}}
          id="combo-box-demo"
          options={getDatastudent}
          getOptionLabel={(option) => option.name}
          renderInput={(params) => <TextField {...params} label="Branch" variant="outlined" />}
        />
      </Grid>
      <Grid item md={2} xs={12}> 
        <Autocomplete
          fullWidth
          style={{width:250}}
          id="combo-box-demo"
          options={getDatastudent}
          getOptionLabel={(option) => option.name}
          renderInput={(params) => <TextField {...params} label="Grade" variant="outlined" />}
        />
      </Grid>
      <Grid item md={2} xs={12}> 
        <Autocomplete 
          fullWidth
          style={{width:250}}
          id="combo-box-demo"
          options={getDatastudent}
          getOptionLabel={(option) => option.name}
          renderInput={(params) => <TextField {...params} label="Section" variant="outlined" />}
        />
      </Grid>
    </Grid>
    {/* <Grid container direction="row" spacing={2}style={{ marginTop: '20px',marginLeft: '10px'}} > */}
    <Grid container direction="row" spacing={2} className="Gview2">
      <AttendenceTable/> 
    </Grid>
  </Layout>
</>
);
};

export default Admin;




























